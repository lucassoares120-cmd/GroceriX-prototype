import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";

function todayISO() {
  const d = new Date();
  const m = String(d.getMonth()+1).padStart(2,"0");
  const day = String(d.getDate()).padStart(2,"0");
  return `${d.getFullYear()}-${m}-${day}`;
}
function uuid() { return Math.random().toString(36).slice(2) + Date.now().toString(36); }
const STORAGE_KEY = "grocerix:data:v1";
const USER_KEY = "grocerix:user";

function saveData(data){ localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
function loadData(){ try{ const r = localStorage.getItem(STORAGE_KEY); return r? JSON.parse(r):{}; }catch{ return {}; } }
function saveUser(user){ if(user) localStorage.setItem(USER_KEY, JSON.stringify(user)); else localStorage.removeItem(USER_KEY); }
function loadUser(){ try{ const r = localStorage.getItem(USER_KEY); return r? JSON.parse(r): null; } catch{ return null; } }

function imageFor(name){
  const map = { leite:"🥛", banana:"🍌", arroz:"🍚", tomate:"🍅", carne:"🥩", pão:"🍞", ovo:"🥚" };
  const key = Object.keys(map).find(k => name.toLowerCase().includes(k));
  return key ? map[key] : "🛒";
}
function funFactFor(name){
  const facts = {
    leite: "O leite é fonte de cálcio e pode ajudar na saúde óssea.",
    banana: "Bananas são ricas em potássio e ótimas para recuperação.",
    arroz: "Arroz é um dos alimentos mais consumidos no mundo.",
    tomate: "Tomates são ricos em licopeno, um antioxidante."
  };
  const key = Object.keys(facts).find(k => name.toLowerCase().includes(k));
  return key ? facts[key] : undefined;
}
function formatBRL(v){ return Number(v||0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"}); }
function getWeekKey(dISO){
  const d = new Date(dISO); const onejan = new Date(d.getFullYear(),0,1);
  const millis = d.getTime()-onejan.getTime();
  const day = Math.floor(millis/86400000)+onejan.getDay();
  const week = Math.ceil(day/7);
  return `${d.getFullYear()}-W${week}`;
}

export default function App(){
  const [user, setUser] = useState(null);
  const [data, setData] = useState({});
  const [dateISO, setDateISO] = useState(todayISO());

  const [name, setName] = useState("");
  const [qty, setQty] = useState(1);
  const [unit, setUnit] = useState("un");
  const [price, setPrice] = useState("");
  const [weight, setWeight] = useState("");
  const [note, setNote] = useState("");

  useEffect(()=>{ setData(loadData()); setUser(loadUser()); },[]);
  useEffect(()=>{ saveData(data); },[data]);

  const dayList = useMemo(()=> data[dateISO] ?? { dateISO, items: [] }, [data, dateISO]);

  function setDayList(updater){
    setData(prev => ({ ...prev, [dateISO]: updater(prev[dateISO] ?? { dateISO, items: [] }) }));
  }

  function lastPriceFor(itemName){
    const all = Object.values(data).flatMap(d=>d.items).filter(i => i.name.toLowerCase()===itemName.toLowerCase());
    const sorted = all.sort((a,b)=> b.createdAt - a.createdAt);
    const latest = sorted.find(i => typeof i.price === "number");
    return latest?.price;
  }

  function addItem(){
    if(!name.trim()) return;
    const item = {
      id: uuid(),
      name: name.trim(),
      qty: qty || 1,
      unit,
      price: price ? Number(price) : undefined,
      weight: weight ? Number(weight) : undefined,
      note: note || undefined,
      image: imageFor(name),
      funFact: funFactFor(name),
      inCart: false,
      createdAt: Date.now(),
    };
    setDayList(prev => ({ ...prev, items: [item, ...prev.items] }));
    setName(""); setQty(1); setUnit("un"); setPrice(""); setWeight(""); setNote("");
  }

  function toggleCart(id, inCart){
    setDayList(prev => ({ ...prev, items: prev.items.map(i => i.id===id? { ...i, inCart } : i) }));
  }
  function updateItem(id, patch){
    setDayList(prev => ({ ...prev, items: prev.items.map(i=> i.id===id? { ...i, ...patch } : i) }));
  }
  function removeItem(id){
    setDayList(prev => ({ ...prev, items: prev.items.filter(i=> i.id!==id) }));
  }

  const parsePrice = (i)=> (i.price ?? 0) * (i.qty || 1);
  const totalsToday = dayList.items.reduce((a,i)=> a+parsePrice(i),0);
  const weekKey = getWeekKey(dateISO);
  const monthKey = dateISO.slice(0,7);
  let weekTotal=0, monthTotal=0;
  for(const [d, list] of Object.entries(data)){
    const tk = getWeekKey(d); const mk = d.slice(0,7);
    const sum = list.items.reduce((a,i)=> a+parsePrice(i),0);
    if(tk===weekKey) weekTotal += sum;
    if(mk===monthKey) monthTotal += sum;
  }

  const toBuy = dayList.items.filter(i=>!i.inCart);
  const inCart = dayList.items.filter(i=>i.inCart);

  function fakeGoogleLogin(){
    const u = { uid: "demo-"+uuid(), name: "Lucas", email: "lucas@example.com" };
    setUser(u); saveUser(u);
  }
  function signOut(){ setUser(null); saveUser(null); }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 text-slate-900">
      <div className="max-w-5xl mx-auto p-4 md:p-8">
        <header className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <motion.div initial={{ rotate: -10, scale: 0.9 }} animate={{ rotate: 0, scale: 1 }} transition={{ type: 'spring', stiffness: 200 }} className="text-3xl">🛍️</motion.div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold tracking-tight">GroceriX</h1>
              <p className="text-sm text-slate-600">Lista de supermercado rápida, bonita e inteligente.</p>
            </div>
          </div>
          <div>
            {user ? (
              <button onClick={signOut} className="px-3 py-2 rounded-xl bg-white border shadow-sm text-sm">Sair</button>
            ) : (
              <button onClick={fakeGoogleLogin} className="px-3 py-2 rounded-xl bg-slate-900 text-white text-sm">Entrar com Google</button>
            )}
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div className="bg-white rounded-2xl border shadow-sm p-4">
            <p className="text-xs text-slate-500">Total da Semana</p>
            <p className="mt-1 text-xl font-semibold">{formatBRL(weekTotal)}</p>
          </div>
          <div className="bg-white rounded-2xl border shadow-sm p-4">
            <p className="text-xs text-slate-500">Total do Mês</p>
            <p className="mt-1 text-xl font-semibold">{formatBRL(monthTotal)}</p>
          </div>
          <div className="bg-white rounded-2xl border shadow-sm p-4">
            <p className="text-xs text-slate-500">Dia Selecionado</p>
            <p className="mt-1 text-xl font-semibold">{formatBRL(totalsToday)}</p>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border p-4 md:p-6">
          <div className="flex flex-col md:flex-row md:items-end gap-3 md:gap-4">
            <div className="flex-1">
              <label className="text-sm">Dia da compra</label>
              <div className="flex items-center gap-2">
                <input type="date" value={dateISO} onChange={e=>setDateISO(e.target.value)} className="max-w-[200px] border rounded-lg px-3 py-2"/>
                <span className="text-slate-500 text-sm">📅</span>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-500">Total do dia</p>
              <p className="text-xl font-semibold">{formatBRL(totalsToday)}</p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-12 gap-3">
            <div className="md:col-span-4">
              <label>Item</label>
              <input placeholder="Ex.: Leite integral" value={name} onChange={e=>setName(e.target.value)} onKeyDown={(e)=>{ if(e.key==='Enter') addItem(); }} className="w-full border rounded-lg px-3 py-2"/>
            </div>
            <div className="md:col-span-2">
              <label>Qtd.</label>
              <input type="number" min={0} step={1} value={qty} onChange={e=>setQty(Number(e.target.value))} className="w-full border rounded-lg px-3 py-2"/>
            </div>
            <div className="md:col-span-2">
              <label>Tipo</label>
              <select value={unit} onChange={e=>setUnit(e.target.value)} className="w-full border rounded-lg px-3 py-2">
                {["un","kg","g","L","mL","pacote","caixa","saco","bandeja","garrafa","lata","outro"].map(u=>(<option key={u} value={u}>{u}</option>))}
              </select>
            </div>
            <div className="md:col-span-2">
              <label>Preço (R$)</label>
              <input inputMode="decimal" placeholder="Ex.: 5,99" value={price} onChange={e=>setPrice(e.target.value.replace(",","."))} className="w-full border rounded-lg px-3 py-2"/>
            </div>
            <div className="md:col-span-2">
              <label>Peso</label>
              <input inputMode="decimal" placeholder="Opcional" value={weight} onChange={e=>setWeight(e.target.value.replace(",","."))} className="w-full border rounded-lg px-3 py-2"/>
            </div>
            <div className="md:col-span-8">
              <label>Observação</label>
              <input placeholder="Ex.: Preferir marca X" value={note} onChange={e=>setNote(e.target.value)} className="w-full border rounded-lg px-3 py-2"/>
            </div>
            <div className="md:col-span-4 flex items-end">
              <button onClick={addItem} className="w-full px-4 py-3 rounded-xl bg-slate-900 text-white flex items-center justify-center gap-2">➕ Adicionar</button>
            </div>
          </div>

          <div className="mt-6 grid md:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span>📝</span><h3 className="font-semibold">Lista</h3>
              </div>
              <div className="space-y-2">
                {toBuy.length===0 && <p className="text-sm text-slate-500">Nada aqui por enquanto. Adicione itens acima.</p>}
                {toBuy.map(i => (
                  <motion.div key={i.id} layout initial={{opacity:0,y:6}} animate={{opacity:1,y:0}} className="bg-white rounded-xl shadow-sm border p-3 flex items-start gap-3">
                    <div className="text-2xl" title={i.name}>{i.image || "🛒"}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-3">
                        <div className="truncate font-medium">{i.name}</div>
                        <div className="text-sm text-slate-600">{typeof i.price==="number" ? formatBRL((i.price||0)*(i.qty||1)) : <span className="text-slate-400">—</span>}</div>
                      </div>
                      <div className="mt-1 grid grid-cols-3 md:grid-cols-6 gap-2 text-sm">
                        <input value={i.qty} onChange={e=>updateItem(i.id,{qty:Number(e.target.value)})} type="number" min={0} step={1} className="border rounded-lg px-2 py-1"/>
                        <select value={i.unit} onChange={e=>updateItem(i.id,{unit:e.target.value})} className="border rounded-lg px-2 py-1">
                          {["un","kg","g","L","mL","pacote","caixa","saco","bandeja","garrafa","lata","outro"].map(u=>(<option key={u} value={u}>{u}</option>))}
                        </select>
                        <input value={i.price ?? ""} onChange={e=>updateItem(i.id,{price:e.target.value?Number(e.target.value.replace(",",".")):undefined})} placeholder="Preço" inputMode="decimal" className="border rounded-lg px-2 py-1"/>
                        <input value={i.weight ?? ""} onChange={e=>updateItem(i.id,{weight:e.target.value?Number(e.target.value.replace(",",".")):undefined})} placeholder="Peso" inputMode="decimal" className="border rounded-lg px-2 py-1"/>
                        <input value={i.note ?? ""} onChange={e=>updateItem(i.id,{note:e.target.value})} placeholder="Obs." className="border rounded-lg px-2 py-1"/>
                        <div className="text-xs text-slate-500 flex items-center">{(lastPriceFor(i.name) && !i.price) ? `Último: ${formatBRL(lastPriceFor(i.name))}` : i.funFact ?? ""}</div>
                      </div>
                      <div className="mt-2 flex items-center gap-2">
                        <button onClick={()=>toggleCart(i.id,true)} className="px-3 py-2 rounded-lg bg-emerald-600 text-white text-sm">Adicionar ao Carrinho</button>
                        <button onClick={()=>removeItem(i.id)} className="px-3 py-2 rounded-lg border text-sm">Remover</button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 mb-2">
                <span>🛒</span><h3 className="font-semibold">Carrinho</h3>
              </div>
              <div className="space-y-2">
                {inCart.length===0 && <p className="text-sm text-slate-500">Nenhum item no carrinho.</p>}
                {inCart.map(i => (
                  <motion.div key={i.id} layout initial={{opacity:0,y:6}} animate={{opacity:1,y:0}} className="bg-white rounded-xl shadow-sm border p-3 flex items-start gap-3">
                    <div className="text-2xl" title={i.name}>{i.image || "🛒"}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-3">
                        <div className="truncate font-medium">{i.name}</div>
                        <div className="text-sm text-slate-600">{typeof i.price==="number" ? formatBRL((i.price||0)*(i.qty||1)) : <span className="text-slate-400">—</span>}</div>
                      </div>
                      <div className="mt-1 grid grid-cols-3 md:grid-cols-6 gap-2 text-sm">
                        <input value={i.qty} onChange={e=>updateItem(i.id,{qty:Number(e.target.value)})} type="number" min={0} step={1} className="border rounded-lg px-2 py-1"/>
                        <select value={i.unit} onChange={e=>updateItem(i.id,{unit:e.target.value})} className="border rounded-lg px-2 py-1">
                          {["un","kg","g","L","mL","pacote","caixa","saco","bandeja","garrafa","lata","outro"].map(u=>(<option key={u} value={u}>{u}</option>))}
                        </select>
                        <input value={i.price ?? ""} onChange={e=>updateItem(i.id,{price:e.target.value?Number(e.target.value.replace(",",".")):undefined})} placeholder="Preço" inputMode="decimal" className="border rounded-lg px-2 py-1"/>
                        <input value={i.weight ?? ""} onChange={e=>updateItem(i.id,{weight:e.target.value?Number(e.target.value.replace(",",".")):undefined})} placeholder="Peso" inputMode="decimal" className="border rounded-lg px-2 py-1"/>
                        <input value={i.note ?? ""} onChange={e=>updateItem(i.id,{note:e.target.value})} placeholder="Obs." className="border rounded-lg px-2 py-1"/>
                        <div className="text-xs text-slate-500 flex items-center">{i.funFact ?? ""}</div>
                      </div>
                      <div className="mt-2 flex items-center gap-2">
                        <button onClick={()=>toggleCart(i.id,false)} className="px-3 py-2 rounded-lg bg-slate-200 text-sm">Voltar p/ Lista</button>
                        <button onClick={()=>removeItem(i.id)} className="px-3 py-2 rounded-lg border text-sm">Remover</button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <footer className="mt-8 text-center text-xs text-slate-500">
          GroceriX — protótipo. Dados ficam só no seu navegador.
        </footer>
      </div>
    </div>
  );
}
