# GroceriX — Protótipo (Vite + React + Tailwind)

Este é o protótipo navegável do app **GroceriX** (lista de supermercado).

## Como rodar localmente
1) Instale Node.js 18+
2) No terminal:
```bash
npm install
npm run dev
```
Abra o endereço exibido (geralmente http://localhost:5173).

## Deploy (Vercel)
1) Crie um repositório no GitHub (ex.: `grocerix-prototype`) e **envie estes arquivos**.
2) No painel da Vercel, clique **Add New → Project → Import** e escolha o repositório.
3) Framework Preset: **Vite** (Build: `npm run build` / Output dir: `dist`).
4) Clique **Deploy**. Pronto!

## Deploy rápido (Netlify)
- Opção 1: Conectar ao GitHub e fazer o deploy contínuo (Build: `npm run build`, Publish dir: `dist`).
- Opção 2: Localmente, rode `npm run build` e arraste a pasta `dist/` para o **Netlify Drop** (deploy instantâneo).

## Observações
- Este protótipo salva dados no `localStorage` e usa um login Google **simulado** (apenas visual).
- Para autenticação real e Firestore, migre para Firebase (Auth + Firestore) no próximo passo.
